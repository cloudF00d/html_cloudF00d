// 팝업 토글
$(document).ready(function () {
    $('#toggle-label').click(function () {
        $('#menu-content').slideToggle(500);
    });
});